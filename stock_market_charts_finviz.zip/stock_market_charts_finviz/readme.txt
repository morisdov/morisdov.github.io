=== Stock market charts from finviz ===
Contributors: Moris Dov
Tags: shortcode, chart, image, ticker, finance
Requires at least: 4.0
Tested up to: 4.5
Stable tag: 1.0.0
License: GPLv2 or later

This plugin adds a shortcode [finviz ticker=GE] to include stock market chart images of a ticker
within your post or page content. The charts are dynamic, meaning they get refreshed even after the content edit time.

== Description ==

This plugin adds a shortcode [finviz ticker=GE] to include stock market chart images of a ticker
within your post or page content. The charts are dynamic, meaning they get refreshed even after the content edit time.
The chart images include a small branded logo of finviz.com.
If desired then the chart images can be optionally hyperlinked to the ticker page at finviz.com web site.

use shortcode [finviz ticker=GM] to include the stock chart of General Motors.

optional link attribute [finviz ticker=GM link=true] to add a hyperlink to finviz.com web site, to the chart image.
optional link attribute [finviz ticker=GM link=false] to remove a default hyperlink to finviz.com web site, from the chart image.
On the plugin settings page you may specify a default 'Add hyperlink to charts' option for all finviz shortcodes.
On the plugin settings page you may specify your own image 'alt text prefix' option for all finviz shortcodes,
the default prefix is 'finviz dynamic chart for  TICKER '.

optional width attribute [finviz ticker=GM width=500] to specify chart image width. 
the default width is 700 pixels.


== Installation ==

This section describes how to install the plugin and get it working.


1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Settings->Plugin Name screen to configure the plugin


== Frequently Asked Questions ==

= Are the charts real time ? =

no, the chart data is delayed by 20 minutes.



== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets 
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png` 
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.0 =
* A change since the previous version.

