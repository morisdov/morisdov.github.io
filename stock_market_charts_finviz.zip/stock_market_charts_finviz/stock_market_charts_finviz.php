<?php
/*
Plugin Name: Stock market charts from finviz
Description: shortcode 'finviz' for stock market charts from  finviz.com
Author: Moris Dov
Author URI: https://profiles.wordpress.org/morisdov
Version: 1.0.0
*/
////////////////////////////////////////////////////////////////////////////////////////
add_action( 'init', 'md_register_shortcode_finviz');

function md_register_shortcode_finviz() {
	add_shortcode('finviz', 'md_shortcode_finviz');
}
function md_shortcode_finviz($attr, $content = null) {
	if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
		$uri = 'https://';
	} else {
		$uri = 'http://';
	}

	// get shortcode attribute
	if ( isset( $attr['ticker'] ) ) {
		if ( strlen($attr['ticker']) <= 7 )
			$ticker = sanitize_text_field( $attr['ticker'] );
    } else {
        $ticker = 'GE';
    }
	if( isset( $attr['width'] ) ) {
		$attr['width'] = (int)$attr['width'];
		if ( $attr['width'] > 10 && $attr['width'] < 1000 )
			$width = $attr['width'];
		else 
			$width = false;
    } else {
		$width = false;
	}

	// get saved options
	$options = get_option('md_finviz');
	// option checkbox
	if( isset( $options['option1'] ) ) {
		if ($options['option1'] == 1 )
			$link = true;
		else
			$link = false;
	} else {
		$link = false;
	}
	// option text
	if( isset( $options['alt_text'] ) ) {
		if (strlen($options['alt_text']) > 1 )
			$alt_text = $options['alt_text'] . ' ' . $ticker;
		else
			$alt_text = "finviz dynamic chart for  $ticker ";
	} else {
		$alt_text = "finviz dynamic chart for  $ticker ";
	}

	// override saved option
	if( isset( $attr['link'] ) ) {
		if ( (bool)$attr['link'] == true  )
			$link = true;
		//else
			//$link = false;
		if ( strtolower($attr['link'])  == 'false')
			$link = false;
    }

	// final string construction
	if ($width)
		$str = '<img src=\'' . $uri . "www.finviz.com/chart.ashx?t=$ticker&ty=c&ta=1&p=d&s=l'  alt='$alt_text'  width='$width' />";
	else
		$str = '<img src=\'' . $uri . "www.finviz.com/chart.ashx?t=$ticker&ty=c&ta=1&p=d&s=l'  alt='$alt_text'   />";

	if ($link)
		$str = '<a href=\'' . $uri . "www.finviz.com/quote.ashx?a=117036537&t=$ticker' target='_blank'>$str</a>";
	
	// result
	return $str;
}

////////////////////////////////////////////////////////////////////////////////////////
// Add the admin options page
add_action('admin_init', 'md_finvizoptions_init' );
add_action('admin_menu', 'md_finvizoptions_add_page');

// Init plugin options to white list our options
function md_finvizoptions_init(){
	register_setting( 'md_finvizoptions_options', 'md_finviz', 'md_finvizoptions_validate' );
}
// Add menu page
function md_finvizoptions_add_page() {
	add_options_page('Stock Market Charts', 'Stock Market Charts', 'manage_options', 'md_finvizoptions', 'md_finvizoptions_do_page');
}

// Draw the menu page itself
function md_finvizoptions_do_page() {
	?>
	<div class="wrap">
		<h2>Stock Market Charts Plugin</h2><br/>
		<div style="margin-left: 50px; background: rgb(215, 215, 215) none repeat scroll 0% 0%; padding: 20px;">
		<b>Instructions</b>
		<p/> use shortcode [finviz ticker=<b>GM</b>] to include the stock chart of <b>General Motors</b>.
		<p/> optional attribute [finviz ticker=GM <b>link=true</b>] to add a hyperlink to <b>finviz.com</b> web site, to the chart image.
		<br/> optional attribute [finviz ticker=GM <b>link=false</b>] to remove a default hyperlink to <b>finviz.com</b> web site, from the chart image.
		<p/> optional attribute [finviz ticker=GM <b>width=500</b>] to specify chart image width.
		</div>
		<form method="post" action="options.php">
			<?php settings_fields('md_finvizoptions_options'); ?>
			<?php $options = get_option('md_finviz'); ?>
			<table class="form-table">
				<tr valign="top"><th scope="row">Add hyperlink to charts</th>
					<td><input name="md_finviz[option1]" type="checkbox" value="1" <?php checked('1', $options['option1']); ?> /></td>
				</tr>
				<tr valign="top"><th scope="row">Chart images alt text prefix</th>
					<td><input type="text" name="md_finviz[alt_text]" value="<?php echo $options['alt_text']; ?>" /></td>
				</tr>
			</table>
			<p class="submit">
			<input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
			</p>
		</form>
	</div>
	<?php	
}

// Sanitize and validate input. Accepts an array, return a sanitized array.
function md_finvizoptions_validate($input) {
	// Our first value is either 0 or 1
	if (array_key_exists('option1', $input))
		$input['option1'] = ( $input['option1'] == 1 ? 1 : 0 );
	// Say our second option must be safe text with no HTML tags
	if (array_key_exists('alt_text', $input))
		$input['alt_text'] =  wp_filter_nohtml_kses($input['alt_text']);

	return $input;
}