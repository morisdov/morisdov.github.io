<?php 
delete_option('md_finviz'); 
?>